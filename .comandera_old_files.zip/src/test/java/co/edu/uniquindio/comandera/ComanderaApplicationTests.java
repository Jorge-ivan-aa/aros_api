package co.edu.uniquindio.comandera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComanderaApplicationTests {

	@Test
	void contextLoads() {
	}

}
