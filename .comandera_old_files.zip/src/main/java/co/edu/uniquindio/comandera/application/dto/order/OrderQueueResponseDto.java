package co.edu.uniquindio.comandera.application.dto.order;

public class OrderQueueResponseDto {
}
