package co.edu.uniquindio.comandera.domain.model;

public record Category(
    Long id,
    String name
) {
}
