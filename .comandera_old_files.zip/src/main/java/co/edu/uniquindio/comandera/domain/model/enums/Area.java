package co.edu.uniquindio.comandera.domain.model.enums;

public enum Area {
    KITCHEN, BAR, SERVICE
}