package co.edu.uniquindio.comandera.domain.model.enums;

/**
 * desing the for what type of date could the area by used
 */
public enum AreaType
{
    // KITCHEN, BAR, SERVICE
    PRODUCTS, WORKERS
}