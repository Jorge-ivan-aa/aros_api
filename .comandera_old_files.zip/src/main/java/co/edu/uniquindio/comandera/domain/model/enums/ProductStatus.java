package co.edu.uniquindio.comandera.domain.model.enums;

public enum ProductStatus {
    IN_PREPARATION,
    PREPARED,
    COMPLETED;
}
